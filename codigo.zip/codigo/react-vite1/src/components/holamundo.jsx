export default function HolaMundo() {
    const nombre = "Pedro";
    const saludo = "Buenos días";
    return <h1>{nombre} saludo: {saludo}</h1>;
    }